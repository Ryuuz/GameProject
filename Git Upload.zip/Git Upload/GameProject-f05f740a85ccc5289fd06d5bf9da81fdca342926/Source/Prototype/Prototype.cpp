// Fill out your copyright notice in the Description page of Project Settings.

#include "Prototype.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Prototype, "Prototype" );
