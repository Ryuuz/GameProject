// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "AIController.h"
#include "AIGuardController.generated.h"

/**
 * 
 */
UCLASS()
class PROTOTYPE_API AAIGuardController : public AAIController
{
	GENERATED_BODY()
	
	
	
	
};
